import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-trip',
  templateUrl: './edit-trip.component.html',
  styleUrls: ['./edit-trip.component.css']
})
export class EditTripComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
